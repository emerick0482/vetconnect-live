import React from 'react';
import ReactDOM from 'react-dom/client';

const App = () => (
  <div>
    <h1>Welcome to VetConnect</h1>
    <p>This is your starter app.</p>
  </div>
);

ReactDOM.createRoot(document.getElementById('root')).render(<App />);